import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector:'app-favorites',
  standalone:true,

  imports:[
    CommonModule
  ],

  templateUrl:'./favorites.html',
  styleUrls:['./favorites.css']
})

export class Favorites {

  favoritos:any[] = JSON.parse(

    localStorage.getItem('favoritos')
    || '[]'
  );
}