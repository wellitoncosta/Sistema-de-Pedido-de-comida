import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ThemeService } from '../../services/theme.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})

export class Login {

  email = '';
  password = '';
  showPassword = false;

  loading = false;
  errorMessage = '';

  constructor(
    private api: ApiService,
    private router: Router,
    public themeService: ThemeService
  ) {}


  togglePassword() {
    this.showPassword = !this.showPassword;
  }


  login() {

    console.log(this.email);
    const senhaSalva = localStorage.getItem('senha_' + this.email);
    if(!this.email || !this.password){
      this.errorMessage = 'Preencha todos os campos';
      return;
    }

    this.loading = true;

    this.api.login({

      email: this.email,
      password: this.password

    }).subscribe({

    next: (res:any) => {

      this.loading = false;

      if(res.success){

        const userData = {

          nome: res.user?.nome || 'Utilizador',

          email: this.email
        };

        console.log(userData);

        localStorage.setItem(
          'user',
          JSON.stringify(userData)
        );

        this.router.navigate(['/app/dashboard']);

      } else {

        this.errorMessage = res.message;
      }
    },
      error: () => {

        this.loading = false;
        this.errorMessage = 'Erro no servidor';
      }
    });
  }

}