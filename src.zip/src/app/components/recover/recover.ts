import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router'; // Adicionado Router e RouterModule

import { EmailService } from '../../services/email.service';

@Component({
  selector: 'app-recover',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule // Adicionado aqui para o Angular reconhecer links de rotas
  ],
  templateUrl: './recover.html',
  styleUrls: ['./recover.css']
})
export class Recover {

  email = '';
  codigo = '';
  codigoGerado = '';
  codigoVerificado = false;
  novaSenha = '';
  confirmarSenha = '';
  etapa = 1;

  emailService = new EmailService();

  // Injetando o Router no construtor
  constructor(private router: Router) {}

  async enviarCodigo() {
    this.codigoGerado = Math.floor(
      100000 + Math.random() * 900000
    ).toString();

    try {
      await this.emailService.enviarCodigo(
        this.email,
        this.codigoGerado
      );
      alert('Código enviado para o email!');
      this.etapa = 2;
    } catch(error) {
      console.log(error);
      alert('Erro ao enviar email');
    }
  }

  verificarCodigo() {
    if(this.codigo === this.codigoGerado){
      this.codigoVerificado = true;
      alert('Código verificado com sucesso');
    } else {
      alert('Código inválido');
    }
  }

  alterarSenha() {
    localStorage.setItem(
      'senha_' + this.email,
      this.novaSenha
    );
    alert('Senha alterada com sucesso!');
  }

  // Nova função para forçar a navegação controlada pelo motor do Angular
  voltarAoLogin() {
    this.router.navigate(['/']);
  }
}