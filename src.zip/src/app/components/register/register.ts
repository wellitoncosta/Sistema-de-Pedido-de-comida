import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})

export class Register {

  nome = '';
  email = '';
  password = '';
  confirmPassword = '';

  errorMessage = '';
  successMessage = '';

  loading = false;

  constructor(
    private api: ApiService,
    private router: Router
  ) {}

  register() {

    this.errorMessage = '';
    this.successMessage = '';

    if(
      !this.nome ||
      !this.email ||
      !this.password ||
      !this.confirmPassword
    ){
      this.errorMessage = 'Preencha todos os campos';
      return;
    }

    if(this.password !== this.confirmPassword){

      this.errorMessage = 'As senhas não coincidem';
      return;
    }

    if(this.password.length < 6){

      this.errorMessage = 'Senha muito curta';
      return;
    }

    this.loading = true;

    this.api.register({

      nome: this.nome,
      email: this.email,
      password: this.password

    }).subscribe({

      next: (res:any) => {

        this.loading = false;

    if(res.success){

        localStorage.setItem(
          'user',
          JSON.stringify({
            nome: this.nome,
            email: this.email
          })
        );

        localStorage.setItem(
          'senha_' + this.email,
          this.password
        );

        localStorage.setItem(
          'senha_' + this.email,
          this.password
        );

        this.successMessage =
        'Conta criada com sucesso';

        setTimeout(() => {

          this.router.navigate(['/']);

        }, 1500);

  } else {

          this.errorMessage = res.message;
        }
      },

      error: () => {

        this.loading = false;

        this.errorMessage =
        'Erro no servidor';
      }
    });
  }
}