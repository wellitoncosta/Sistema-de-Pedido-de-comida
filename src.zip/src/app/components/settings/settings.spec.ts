import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SettingsComponent } from './settings';

describe('SettingsComponent', () => {

  let component: SettingsComponent;

  let fixture: ComponentFixture<SettingsComponent>;

  beforeEach(async () => {

    await TestBed.configureTestingModule({

      imports: [SettingsComponent],

    }).compileComponents();

    fixture =
    TestBed.createComponent(SettingsComponent);

    component =
    fixture.componentInstance;

    await fixture.whenStable();

  });

  it('should create', () => {

    expect(component).toBeTruthy();

  });

});
